DELIMITER $$

    CREATE FUNCTION transformaRefrigerante( v_refri INT) 
    RETURNS varchar(20)

    BEGIN
        DECLARE refri varchar(20);
        
        IF (v_refri > 0) THEN
        SET refri = 'refrigerante sim';
        

        ELSEIF (v_refri <= 0) THEN
        SET refri = 'refrigerante não';
        END IF;
        RETURN refri;
    END;
$$

SELECT transformaRefrigerante(pedidos_full.valor_borda) from pedidos_full;