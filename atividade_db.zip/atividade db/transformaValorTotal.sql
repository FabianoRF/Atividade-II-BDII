DELIMITER $$

    CREATE FUNCTION transformaValorTotal( valor_total INT) 
    RETURNS varchar(20)

    BEGIN
        DECLARE vt varchar(20);
        
        IF (valor_total >= 10 AND valor_total < 14) THEN
        	SET vt = '10-14';
        
        ELSEIF (valor_total >= 14 AND valor_total < 18) THEN
            SET vt = '14-18';
        
        ELSEIF (valor_total >= 18 AND valor_total < 22) THEN
            SET vt = '18-22';
        
        ELSEIF (valor_total >= 22 AND valor_total < 26) THEN
            SET vt = '22-26';
      
        ELSEIF (valor_total >= 26 AND valor_total < 30) THEN
            SET vt = '26-30';
            
        ELSEIF (valor_total >= 30 AND valor_total < 34) THEN
            SET vt = '30-34';
        
        ELSEIF (valor_total >= 34 AND valor_total < 38) THEN
            SET vt = '34-38';
         
        ELSEIF (valor_total >= 38 AND valor_total < 42) THEN
            SET vt = '38-42';
         
        ELSEIF (valor_total >= 42 AND valor_total < 46) THEN
            SET vt = '42-46';
         
        ELSEIF (valor_total >= 46 AND valor_total < 50) THEN
            SET vt = '46-50';
         
        ELSEIF (valor_total >= 50 AND valor_total < 54) THEN
            SET vt = '50-54';
        END IF;
        RETURN vt;
    END;
$$

SELECT transformaValorTotal(pedidos_full.`valor_total`) from pedidos_full;