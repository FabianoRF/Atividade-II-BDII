DELIMITER $$

    CREATE FUNCTION transformaTempoDecorrido( tempo_decorrido TIME) 
    RETURNS varchar(20)

    BEGIN
        DECLARE td varchar(20);
        
        IF (tempo_decorrido >= '00:10:00' AND tempo_decorrido < '00:15:00') THEN
        	SET td = '10-15';
        
        ELSEIF (tempo_decorrido >= '00:15:00' AND tempo_decorrido < '00:20:00') THEN
            SET td = '15-20';
        
        ELSEIF (tempo_decorrido >= '00:20:00' AND tempo_decorrido < '00:25:00') THEN
            SET td = '20-25';
        
        ELSEIF (tempo_decorrido >= '00:25:00' AND tempo_decorrido < '00:30:00') THEN
            SET td = '25-30';
      
        ELSEIF (tempo_decorrido >= '00:30:00' AND tempo_decorrido < '00:35:00') THEN
            SET td = '30-35';
            
        ELSEIF (tempo_decorrido >= '00:35:00' AND tempo_decorrido < '00:40:00') THEN
            SET td = '35-40';
        
        ELSEIF (tempo_decorrido >= '00:40:00' AND tempo_decorrido < '00:45:00') THEN
            SET td = '40-45';
         
        ELSEIF (tempo_decorrido >= '00:45:00' AND tempo_decorrido < '00:50:00') THEN
            SET td = '45-50';
         
        ELSEIF (tempo_decorrido >= '00:50:00' AND tempo_decorrido < '00:55:00') THEN
            SET td = '50-55';
         
        ELSEIF (tempo_decorrido >= '00:55:00' AND tempo_decorrido < '00:60:00') THEN
            SET td = '55-60';
        END IF;
        RETURN td;
    END;
$$

SELECT transformaTempoDecorrido(pedidos_full.tempo) FROM pedidos_full
