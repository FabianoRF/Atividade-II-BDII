DELIMITER $$

    CREATE FUNCTION transformaBorda( v_borda INT) 
    RETURNS varchar(20)

    BEGIN
        DECLARE borda varchar(20);
        
        IF (v_borda > 0) THEN
        SET borda = 'borda sim';
        

        ELSEIF (v_borda <= 0) THEN
        SET borda = 'borda não';
        END IF;
        RETURN borda;
    END;
$$

SELECT transformaBorda(pedidos_full.valor_borda) from pedidos_full;