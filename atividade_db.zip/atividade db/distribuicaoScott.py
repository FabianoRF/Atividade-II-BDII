import numpy as np
import matplotlib.mlab as mlab
import matplotlib.pyplot as plt
import csv
import math

"""
import pandas as pd
data = pd.read_csv("valor_total.csv")
data.head()
data.hist(bins="scott")
print(data) 
"""

def distribuicao(d = []):
        k = round(1 + 3 * math.log10(len(d)))
        maior = int(max(d))
        menor = int(min(d))
        a = round(((maior - menor) / k) + 0.5)
        print(f"k: {k}, a: {a}, mim: {menor}, mar: {maior}")


def lerDados(caminho):
        arquivo = open(caminho)
        linhas = csv.reader(arquivo)
        dados = []
        
        for linha in linhas:
            dados.append(linha[0])
        return dados


def tempoEmMinutos(horario):
    hora = float(horario[0:2])* int(3600)
    minuto = float(horario[3:5])* int(60)
    segundo = float(horario[6:8])
    C = int((hora + minuto + segundo) / 60)
    return C
    

def transformaTempo(dados):
    for i in range(0, len(dados)):
        s = tempoEmMinutos(dados[i])
        dados[i] = s
    return dados


valor_total = lerDados('valor_total.csv')
distribuicao(valor_total)

tempo_decorrido = lerDados('tempo_decorrido.csv')
tempo_decorrido = transformaTempo(tempo_decorrido)
distribuicao(tempo_decorrido)
     
"""
histograma1 = plt.hist(valor_total, bins="scott")
plt.show()
"""

histograma2 = plt.hist(tempo_decorrido, bins="scott")
plt.show()
